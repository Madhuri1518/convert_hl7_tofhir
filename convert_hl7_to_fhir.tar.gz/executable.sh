#!/bin/bash
node $( dirname -- "$0"; )/convertHL7ToFHIR.js "$@"